
import ScanMathIntegration from './ScanMathIntegration';
export default function ResultsMathEmbed({ bet }) {
  return <ScanMathIntegration bet={bet} />;
}