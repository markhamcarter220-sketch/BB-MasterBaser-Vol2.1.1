// normalizeOdds.js - normalize or transform raw odds data if required.
function normalizeOdds(raw) {
  return raw;
}
module.exports = { normalizeOdds };