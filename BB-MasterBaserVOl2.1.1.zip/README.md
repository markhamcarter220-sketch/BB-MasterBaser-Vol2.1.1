# BB-MasterBaser (Scrubbed)

This is a deep-scrubbed snapshot of your project, reorganized for clarity.

## Structure
- `frontend/` – client app (React/Vite/Next, etc.)
- `backend/` – server app (Express/Fastify, etc.)
- `SCRUB_REPORT.md` – what was removed and why, with next steps.
